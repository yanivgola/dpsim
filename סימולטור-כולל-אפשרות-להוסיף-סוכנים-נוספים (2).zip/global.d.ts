
// global.d.ts
// JSX.IntrinsicElements augmentation has been moved to types.ts
// This file can be kept for other truly global type declarations if needed in the future,
// or removed if no longer necessary.

export {}; // Make this file a module.
